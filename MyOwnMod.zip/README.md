# unit-kiros
A mod add unit to game.

by Tweu2 

# THIS MOD ONLY PLAYABLE ON V7
# Mod lore (real)
There is lore, the virus that control we's unit and fighting with we virus that call "red extra robotic spore"

# To do list
- they will kill all us, We can't escape


